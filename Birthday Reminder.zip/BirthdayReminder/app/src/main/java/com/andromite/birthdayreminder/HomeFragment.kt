package com.andromite.birthdayreminder

import android.graphics.Color
import android.graphics.drawable.shapes.Shape
import android.os.Build
import android.os.Bundle
import android.transition.TransitionManager
import android.transition.Visibility
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.shape.ShapeAppearanceModel
import com.google.android.material.transition.Hold
import com.google.android.material.transition.MaterialArcMotion
import com.google.android.material.transition.MaterialContainerTransform
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.fragment_home.*
import kotlinx.android.synthetic.main.fragment_home.view.*

/**
 * A simple [Fragment] subclass.
 */
class HomeFragment : Fragment() {

    lateinit var addBirth: AddBirthdayFragment
    lateinit var home: HomeFragment
    lateinit var floating_action_button: FloatingActionButton


    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_home, container, false)

        view.floating_action_button.setOnClickListener {

            val transform: MaterialContainerTransform = MaterialContainerTransform().apply {
                startView = view.floating_action_button
                endView = view.cl_one
                pathMotion = MaterialArcMotion()
                scrimColor = Color.TRANSPARENT
                duration = 3000
            }

            TransitionManager.beginDelayedTransition(view.cl_main, transform)
            view.floating_action_button.visibility = View.GONE
            view.cl_one.visibility = View.VISIBLE

        }




//        addBirth = AddBirthdayFragment()
//        addBirth.sharedElementEnterTransition = MaterialContainerTransform().apply {
//
//            duration = 1500
//            pathMotion = MaterialArcMotion()
//            scrimColor = Color.TRANSPARENT
//            exitTransition = Hold()
//
//
//        }
//
//        floating_action_button = view.findViewById(R.id.floating_action_button)
//
//        floating_action_button.setOnClickListener {
//
//            activity!!.supportFragmentManager.beginTransaction()
//                .addSharedElement(it,"shared_element_container")
//                .replace(R.id.frame_layout,addBirth,"home")
//                .addToBackStack("home")
//                .commit()
//
//        }
//
//
//
    return view
//    }


    }
}
